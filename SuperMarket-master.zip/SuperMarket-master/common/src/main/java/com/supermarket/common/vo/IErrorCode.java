package com.supermarket.common.vo;

/**
 * 封装API的错误码
 * Created by ydl on 2021/02/19
 */
public interface IErrorCode {
    Integer getCode();

    String getMessage();
}
